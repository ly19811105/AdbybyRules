// ==UserScript==
// @author            Hunlongyu
// @name              『小助手』资源助手
// @namespace         https://github.com/Hunlongyu
// @icon              https://i.loli.net/2019/04/22/5cbd720718fdb.png
// @description       匹配 m3u8 资源，点击链接，即跳转到播放器页面自动缓冲播放。
// @version           0.5.5
// @include           *://okzy.co/*
// @include           *://www.zuidazy*.*/*
// @include           *://www.subo988.com/*
// @include           *://www.zuixinzy.cc/*
// @include           *://www.209zy.com/*
// @include           *://135zy0.com/*
// @include           *://www.kankanzy.com/*
// @include           *://www.mahuazy.com/*
// @include           *://www.baiwanzy.com/*
// @grant             GM_xmlhttpRequest
// @grant             GM_setClipboard
// @grant             GM_addStyle
// @run-at            document-end
// @supportURL        https://gist.github.com/Hunlongyu/31f7a08294efdacebcce9b527afb1c11
// note               2019/07/31 新增对 MP4 格式支持，更新了资源网站
// note               2019/08/05 视频名称获取更准确
// note               2019/08/09 适配更多资源网站
// note               2019/10/28 移除无效资源网站 播放页面支持一键生成标题和短网址
// note               2019/11/15 资源页面支持一键生成短网址, 并优化了页面
// note               2019/11/18 切换百度短网址为 suo短网址,次数没有限制
// note               2020/01/03 更新资源网站,修复集数显示错误问题
// note               2020/01/06 优化界面,移除广告推广
// ==/UserScript==

(function () {
  'use strict'

  const css = {
    okzy: `
      table, .tvidx, .xing_top_right, .foot, .vodAd{ display: none !important; }
    `,
    zuidazy: `
      table, .tvidx, .xing_top_right, .foot, .vodAd{ display: none !important; }
    `,
    mahuazy: `
      p, .xing_top_right, .foot, .vodAd{ display: none !important; }
    `,
    subo: `
      table, .xing_top_right, .foot, .vodAd{ display: none !important; }
    `,
    zuixinzy: `
      table, .tvidx, .xing_top_right, .announcement, .foot, .vodAd{ display: none !important; }
    `,
    '209zy': `
      table, #topBar, .xing_top_right, .foot, .vodAd{ display: none !important; }
    `,
    '135zy0': `
      table, #topBar, .xing_top_right, .foot, .vodAd{ display: none !important; }
    `,
    kankanzy: `
      #topBar, .xing_top_right, .foot{ display: none !important; }
    `,
    baiwanzy: `
      table, #topBar, .xing_top_right, .foot, .vodAd{ display: none !important; }
    `
  }

  // code here
  const player = {
    title: '',
    m3u8: [],
    shortUrlArr: [],
    init () {
      console.clear()
      console.log('『小助手』 已启动！')
      this.addCss()
      this.getTitle()
    },
    addCss () { // 优化界面,移除广告推广等
      const link = window.location.host
      for (let i in css) {
        if (link.indexOf(i) > -1) {
          GM_addStyle(css[i])
        }
        if (link.indexOf('135zy0') > -1) {
          document.querySelector('img').style.display = 'none'
        }
        if (link.indexOf('kankanzy') > -1) {
          document.querySelector('img').style.display = 'none'
        }
      }
    },
    getTitle () { // 判断是否是资源页面,并获取资源名称
      let h2 = document.querySelector('.vodh > h2')
      if (h2) {
        this.title = h2.innerText
        this.getUrl()
        this.createDom()
        this.hideBtns()
      }
    },
    getUrl () { // 获取资源链接 并 转换为播放链接
      let list = document.querySelectorAll('input[name*="copy_"]')
      let k = 0
      if (list.length > 3) {
        for (let i in list) {
          let v = list[i].value
          if (v !== undefined) {
            if (v.indexOf('.m3u8') !== -1) {
              k++
              this.m3u8.push(v)
              let a = `<a href="http://m3u8.hunlongyu.fun/?url=${v}&title=${this.title} 第${k}集" target="_blank">${this.title} 第${k}集</a>`
              list[i].parentNode.innerHTML = a
            }
          }
        }  
      } else {
        for (let i in list) {
          let v = list[i].value
          if (v !== undefined) {
            if (v.indexOf('.m3u8') !== -1) {
              this.m3u8.push(v)
              let a = `<a href="http://m3u8.hunlongyu.fun/?url=${v}&title=${this.title}" target="_blank">${this.title}</a>`
              list[i].parentNode.innerHTML = a
            }
          }
        }
      }
    },
    hideBtns () { // 隐藏原始功能按钮
      let btns = ['.copy1', '.copy2', '.copy3']
      for (let i in btns) {
        document.querySelector(btns[i]).style.display = 'none'
      }
    },
    createDom () { // 创建 dom btn 节点
      let lt = document.querySelector('.playBox > .liketitle')
      let ltp = lt.parentNode
      let dom = document.createElement('div')
      dom.setAttribute('class', 'ibox playBox')
      dom.innerHTML = `
        <div class="playBar liketitle"><strong>资源短网址:</strong></div>
        <div class="vodplayinfo zy-btns"></div>
      `
      ltp.parentNode.insertBefore(dom, ltp.nextSibling)

      let btns = document.querySelector('.zy-btns')
      let btn = document.createElement('button')
      btn.innerText = '一键获取资源短网址'
      btns.appendChild(btn)
      btn.addEventListener('click', () => {
        this.zyUrlToPlayUrl()
      })
    },
    zyUrlToPlayUrl () { // 资源链接转播放链接
      let arr = []
      if (this.m3u8.length === 0) {
        return false
      }
      if (this.m3u8.length >= 1) {
        arr = this.m3u8
      }
      arr.forEach((i, j) => {
        let url = `http://m3u8.hunlongyu.fun/?url=${i}&title=${this.title}%20第${j+1}集`
        this.suoDwz(url, j+1)
      })
      setTimeout(() => {
        this.urlToClipboard()
      }, 1500)
    },
    playUrlToShortUrl (url, index) { // 资源链接转百度短网址
      let longUrl = url
      let termOfValidity = '1-year'
      let data = JSON.stringify({
        Url: longUrl,
        TermOfValidity: termOfValidity
      })
      GM_xmlhttpRequest({
        method: "POST",
        url: 'https://dwz.cn/admin/v2/create',
        headers: {
          "Content-Type": "application/json; charset=UTF-8",
          "Token": "f9f60d13b72bfbbab857b72abdd19f73"
        },
        data: data,
        onload: res => {
          if (res.status === 200) {
            let response = JSON.parse(res.response)
            let url = response.ShortUrl
            let arr = [index, url]
            this.shortUrlArr.push(arr)
          }
        }
      })
    },
    suoDwz (url, index) { // 资源链接转 suo短网址
      let data = `?format=json&url=${url}&key=5dc8c9d18e676d50a04f8065@950898f4c96ba24cc28a309d4c33b325`
      console.log(data)
      GM_xmlhttpRequest({
        method: "GET",
        url: 'http://suo.im/api.htm' + data,
        data: data,
        onload: res => {
          if (res.status === 200) {
            let response = JSON.parse(res.response)
            let url = response.url
            let arr = [index, url]
            this.shortUrlArr.push(arr)
          }
        }
      })
    },
    urlToClipboard () { // 短网址复制到剪贴板
      let txt = ''
      if (this.shortUrlArr.length === 1) {
        txt = `资源: ${this.title}\n地址: ${this.shortUrlArr[0][1]}`
      }
      if (this.shortUrlArr.length > 1) {
        txt = `资源: ${this.title}\n`
        function ascend (a, b) {
          return a[0] - b[0]
        }
        let newArr = this.shortUrlArr
        newArr.sort(ascend)
        newArr.forEach(i => {
          txt += `第${i[0]}集: ${i[1]}\n`
        })
      }
      GM_setClipboard(txt)
    }
  }
  player.init()
})()